(() => {
  const clean = s => (s || '').replace(/[\s\u00a0]+/g, ' ').trim();
  const cells = row => [...row.children].filter(c => /^(TD|TH)$/.test(c.tagName));
  const text = el => clean(el.textContent);
  function parseList(doc) {
    const form = doc.querySelector('form#searchfrm');
    if (!form) throw new Error('未读取到官网结果表单，可能需要重新打开检索页或完成人工验证。');
    const params = {};
    for (const el of form.querySelectorAll('input[name],select[name]')) params[el.name] = el.value;
    const rows = [...doc.querySelectorAll('tr')].map(tr => {
      const cs = cells(tr);
      if (cs.length !== 6 || !/^CTR\d{8}$/.test(text(cs[1]))) return null;
      const a = cs[1].querySelector('a');
      if (!a?.id || !a.getAttribute('name')) throw new Error('详情链接标识缺失');
      return {summary: cs.map(text), id: a.id, index: a.getAttribute('name')};
    }).filter(Boolean);
    const body = clean(doc.body.textContent);
    const m = body.match(/当前第\s*(\d+)\s*页，共\s*(\d+)\s*页，共\s*(\d+)\s*条记录/);
    if (!m) throw new Error('无法识别官网分页，停止以免漏页。');
    const [page, pages, total] = m.slice(1).map(Number);
    if (total > 0 && rows.length === 0) throw new Error('列表为空但官网条数非零');
    return {params, rows, page, pages, total};
  }
  function parseDetail(doc, ctr) {
    const keys = new Set(['登记号','试验专业题目','试验通俗题目','药物名称','适应症','试验分期','入选标准','排除标准','联系人姓名','联系人座机','联系人手机号','联系人Email','首次公示信息日期','健康受试者']);
    const d = {};
    for (const row of doc.querySelectorAll('tr')) {
      const cs = cells(row);
      for (let i = 0; i < cs.length - 1; i++) {
        const key = text(cs[i]).replace(/[:：]$/, '');
        if (!keys.has(key)) continue;
        if (key === '入选标准' || key === '排除标准') {
          const table = cs[i + 1].querySelector('table');
          if (!table && text(cs[i + 1])) d[key] = [text(cs[i + 1])];
          if (table) d[key] = [...table.querySelectorAll('tr')].map(r => cells(r)).filter(c => c.length >= 2).map(c => text(c.at(-1)));
        } else if (!(key in d)) d[key] = text(cs[i + 1]);
      }
    }
    if (d['登记号'] !== ctr) throw new Error(`详情CTR不匹配：${ctr}`);
    if (!(d['试验专业题目'] || d['试验通俗题目'])) throw new Error('缺少项目名');
    if (!d['入选标准']?.length || !d['排除标准']?.length) throw new Error('入排信息未读全');
    d['主要研究者'] = [];
    for (const table of doc.querySelectorAll('table')) {
      const matrix = [...table.querySelectorAll('tr')].filter(r => r.closest('table') === table).map(r => cells(r).map(text));
      const labels = new Set(matrix.flat());
      if (!(labels.has('姓名') && labels.has('单位名称'))) continue;
      let person = null;
      for (const cs of matrix) for (let i = 0; i < cs.length - 1; i++) {
        if (cs[i] === '姓名') {
          if (person) d['主要研究者'].push(person);
          person = {'姓名': cs[i + 1] || '页面未公开'};
        } else if (person && ['电话','Email','单位名称'].includes(cs[i])) person[cs[i]] = cs[i + 1] || '页面未公开';
      }
      if (person) d['主要研究者'].push(person);
    }
    const clone = doc.body.cloneNode(true);
    clone.querySelectorAll('script,style').forEach(e => e.remove());
    const section = clean(clone.textContent).split(/六、\s*试验状态信息/)[1];
    const status = section?.match(/进行中\s*[（(]\s*[^）)]+[）)]|已完成|主动暂停|主动终止|IEC\/IRB暂停|IEC\/IRB终止|责令暂停|责令终止/);
    if (!status) throw new Error('详情试验状态缺失');
    d['试验状态'] = clean(status[0]);
    d['抓取时间'] = new Date().toISOString();
    return d;
  }
  globalThis.CDEParser = {parseList, parseDetail};
})();
