(() => {
  if (globalThis.__cdeCollectorInstalled) return;
  globalThis.__cdeCollectorInstalled = true;
  let running = false, stopped = false;
  const send = async message => {const r=await chrome.runtime.sendMessage(message); if (!r?.ok) throw new Error(r?.error || '扩展连接中断'); return r.data;};
  const pause = ms => new Promise(r => setTimeout(r,ms));
  const read = html => new DOMParser().parseFromString(html, 'text/html');
  async function fetchDoc(path, params) {
    if (location.hostname !== 'www.chinadrugtrials.org.cn' || location.protocol !== 'https:') throw new Error('只支持CDE官网HTTPS页面');
    if (!['/clinicaltrials.searchlist.dhtml','/clinicaltrials.searchlistdetail.dhtml'].includes(path)) throw new Error('请求路径不在公开检索范围');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(),45000);
    try {
      const response = await fetch(path,{method:'POST',body:new URLSearchParams(params),credentials:'same-origin',signal:controller.signal});
      if (response.status !== 200) throw new Error(`官网返回 HTTP ${response.status}，已暂停；请在官网检查访问状态。`);
      if(new URL(response.url).origin!==location.origin) throw new Error('官网响应跳转到其他网站，已停止');
      return read(await response.text());
    } finally {clearTimeout(timer);}
  }
  async function run(options) {
    if (running) throw new Error('当前页面已有采集任务');
    running = true; stopped = false;
    const coverage=[]; let count=0;
    const status = async message => send({type:'status',status:{message,running:running && !stopped,count},coverage});
    try {
      const seed = CDEParser.parseList(document);
      const failedThisRun = new Set();
      const existing = new Set(await send({type:'keys'}));
      const delay=Math.max(4,Number(options.delay)||4)*1000;
      const limit=Math.max(0,Number(options.limit)||0);
      const keywords=[...new Set(options.keywords.map(s=>s.trim()).filter(Boolean))];
      if (!keywords.length) throw new Error('请填写至少一个适应症关键词');
      for (const keyword of keywords) {
        const check={keyword,declared:0,pages:0,found:0,complete:false,failed:0,error:''}; coverage.push(check);
        let params={...seed.params,keywords:'',reg_no:'',case_no:'',drugs_name:'',drugs_type:'',appliers:'',communities:'',researchers:'',agencies:'',indication:keyword,state:'进行中',id:'',ckm_index:'',currentpage:'1'};
        const seen=new Set(); let initial=null;
        for (let expected=1;;expected++) {
          if(stopped) return;
          await status(`正在读取“${keyword}”第${expected}页；本次已保存${count}条`);
          await pause(delay);
          const list=CDEParser.parseList(await fetchDoc('/clinicaltrials.searchlist.dhtml',params));
          if(list.page !== expected) throw new Error('分页未前进，任务已暂停');
          if(initial===null) initial=list.total;
          check.declared=list.total; check.pages=list.page;
          for(const row of list.rows) {
            const ctr=row.summary[1]; seen.add(ctr); check.found=seen.size;
            if(stopped) return;
            if(existing.has(ctr)) {await send({type:'match',ctr,keyword});continue;}
            if(failedThisRun.has(ctr)){check.failed++;continue;}
            await pause(delay);
            const detailDoc=await fetchDoc('/clinicaltrials.searchlistdetail.dhtml',{...list.params,id:row.id,ckm_index:row.index});
            let detail;
            try {detail=CDEParser.parseDetail(detailDoc,ctr);}
            catch(e){check.failed++;failedThisRun.add(ctr);await send({type:'failure',failure:{ctr,summary:row.summary,keyword,error:String(e.message),html:detailDoc.documentElement.outerHTML,time:new Date().toISOString()}});await status(`已记录待补采${ctr}，继续下一条`);continue;}
            await send({type:'record',record:{ctr,summary:row.summary,detail,keywords:[keyword]}});
            existing.add(ctr); count++;
            await status(`已保存${ctr}；本次${count}条`);
            if(limit && count>=limit) {check.error='达到本次试采上限，未完成全量'; return;}
          }
          if(list.page>=list.pages) {
            check.pagesComplete=seen.size===list.total && list.total===initial;
            check.complete=check.pagesComplete && check.failed===0;
            if(!check.complete) check.error=check.failed ? `${check.failed}条详情待补采` : '官网条数或去重后的记录数不一致，需要复核';
            break;
          }
          params={...list.params,id:'',ckm_index:'',currentpage:String(expected+1)};
        }
      }
    } catch(e) {
      if(coverage.length) coverage.at(-1).error=String(e.message || e);
      await status(`采集暂停：${e.message || e}`);
      throw e;
    } finally {
      running=false;
      const error=coverage.find(c=>c.error)?.error;
      const message=error ? `已停止：${error}。本次保存${count}条。` : stopped ? `已暂停，本次保存${count}条，可继续采集。` : coverage.length && coverage.every(c=>c.complete) ? `本次关键词页面已读完，保存${count}条。请复核肿瘤范围。` : `本次保存${count}条，检索尚未完成。`;
      await status(message);
    }
  }
  chrome.runtime.onMessage.addListener((message,sender,respond)=>{
    if(message.type==='start') {
      if(running) {respond({ok:false,error:'当前页面已有任务'});return;}
      run(message.options).catch(console.error);
      respond({ok:true});
    } else if(message.type==='stop') {stopped=true;respond({ok:true});}
    else if(message.type==='ping') respond({ok:true,running});
  });
})();
