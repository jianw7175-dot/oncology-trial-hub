const $=id=>document.getElementById(id);
const show=message=>$('status').textContent=message;
async function current(){
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.url?.startsWith('https://www.chinadrugtrials.org.cn/clinicaltrials.searchlist.dhtml')) throw new Error('请先切换到CDE官网的查询结果页，再点击扩展。');
  return tab;
}
async function send(message){const r=await chrome.runtime.sendMessage(message);if(!r?.ok)throw new Error(r?.error||'本地数据读取失败');return r.data;}
$('start').onclick=async()=>{
  try{
    const tab=await current();
    const keywords=$('keywords').value.split(/[,，\n]/).map(s=>s.trim()).filter(Boolean);
    const limit=Number($('limit').value);
    if(!keywords.length || !Number.isInteger(limit) || limit<0) throw new Error('关键词和采集上限不正确');
    const saved=await chrome.storage.local.get('status');
    if(saved.status?.running) {
      let alive=false;
      try{alive=(await chrome.tabs.sendMessage(saved.status.tabId,{type:'ping'}))?.running;}catch{}
      if(alive) throw new Error('已有任务运行，请先在原采集标签页暂停。');
    }
    await chrome.scripting.executeScript({target:{tabId:tab.id},files:['parser.js','navigation.js']});
    const r=await chrome.tabs.sendMessage(tab.id,{type:'nav-begin',options:{keywords,limit,delay:4}});
    if(!r?.ok) throw new Error(r?.error||'启动失败');
    show('正在采集，保持官网标签页打开。');
  }catch(e){show(e.message);}
};
$('stop').onclick=async()=>{try{await send({type:'nav-stop'});show('已暂停，保留已保存的数据。');}catch(e){show(e.message);}};
function download(name,text,type){const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}
$('export').onclick=async()=>{
  try{
    const data=await send({type:'export'});
    const headers=['CTR','项目名','入选标准全文','排除标准全文','主要研究者','研究者单位','研究者电话','研究者邮箱','申请人联系人','申请人电话','申请人邮箱','状态','抓取时间','官网检索链接'];
    const rows=data.records.filter(r=>r.detail['试验状态'].startsWith('进行中') && r.detail['试验状态'].includes('招募中')).map(r=>{const d=r.detail,pi=k=>d['主要研究者'].map(p=>p[k]||'页面未公开').join('\n')||'页面未公开';return [r.ctr,d['试验专业题目']||d['试验通俗题目'],d['入选标准'].map((s,i)=>`${i+1}. ${s}`).join('\n'),d['排除标准'].map((s,i)=>`${i+1}. ${s}`).join('\n'),pi('姓名'),pi('单位名称'),pi('电话'),pi('Email'),d['联系人姓名'],[d['联系人座机'],d['联系人手机号']].filter(Boolean).join(' / '),d['联系人Email'],d['试验状态'],d['抓取时间'],`https://www.chinadrugtrials.org.cn/clinicaltrials.searchlist.dhtml?keywords=${r.ctr}`];});
    const csv=[headers,...rows].map(row=>row.map(v=>{let s=String(v??'');if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}).join(',')).join('\r\n');
    download('CDE浏览器采集.json',JSON.stringify(data,null,2),'application/json');
    download('CDE招募中项目.csv','\ufeff'+csv,'text/csv;charset=utf-8');
    show(`已导出${rows.length}条招募中项目，请查看检索覆盖，部分采集不代表全量。`);
  }catch(e){show(e.message);}
};
async function refresh(){const {status}=await chrome.storage.local.get('status');if(status)show(status.message);}
refresh();chrome.storage.onChanged.addListener(changes=>{if(changes.status)show(changes.status.newValue.message);});
