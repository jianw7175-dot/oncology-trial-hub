(() => {
  if(globalThis.__cdeNavigationLoaded)return;
  globalThis.__cdeNavigationLoaded=true;
  const send=async message=>{const r=await chrome.runtime.sendMessage(message);if(!r?.ok)throw new Error(r?.error||'扩展连接中断');return r.data;};
  const pause=ms=>new Promise(r=>setTimeout(r,ms));
  async function save(j,message){await send({type:'nav-save',job:j,message});}
  async function navigate(j,path,params){
    await save(j,`页面采集：${j.keywords[j.key]} 第${j.page}页，新增${j.count}条`);
    await pause(5000);
    if(!(await send({type:'nav-get'}))?.running)return;
    if(!['/clinicaltrials.searchlist.dhtml','/clinicaltrials.searchlistdetail.dhtml'].includes(path))throw new Error('非公开检索路径');
    const f=document.createElement('form');f.method='POST';f.action=path;f.target='_self';
    for(const [name,value] of Object.entries(params)){const e=document.createElement('input');e.type='hidden';e.name=name;e.value=value??'';f.appendChild(e);}
    document.body.appendChild(f);f.submit();
  }
  function params(j){return {...j.seed,keywords:'',reg_no:'',case_no:'',drugs_name:'',drugs_type:'',appliers:'',communities:'',researchers:'',agencies:'',indication:j.keywords[j.key],state:j.recruiting,id:'',ckm_index:'',currentpage:String(j.page),secondLevel:'1'};}
  async function advance(j){
    if(j.limit && j.count>=j.limit){j.running=false;await save(j,`试采完成：新增${j.count}条，尚未全量完成`);return;}
    if(j.queue.length){j.current=j.queue.shift();j.stage='detail';await navigate(j,'/clinicaltrials.searchlistdetail.dhtml',{...j.listParams,id:j.current.id,ckm_index:j.current.index});return;}
    if(j.page<j.pageCount){j.page++;j.stage='list';await navigate(j,'/clinicaltrials.searchlist.dhtml',params(j));return;}
    const c=j.coverage[j.key];c.pagesComplete=c.found===c.declared && c.declared===c.initial;c.complete=c.pagesComplete && !c.failed;
    c.error=c.failed?`${c.failed}条详情待补采`:c.pagesComplete?'':'数量变动或重复，需复核';
    j.key++;j.page=1;j.seen=[];
    if(j.key>=j.keywords.length){j.running=false;await save(j,j.coverage.every(c=>c.complete)?`六关键词页面采集完成，新增${j.count}条；待复核肿瘤范围`:`页面遍历结束，存在待补采或数量差异；新增${j.count}条`);return;}
    j.stage='list';await navigate(j,'/clinicaltrials.searchlist.dhtml',params(j));
  }
  async function step(j){
    try{
      if(j.stage==='list'){
        const list=CDEParser.parseList(document);
        if(list.page!==j.page || list.params.indication!==j.keywords[j.key] || list.params.state!==j.recruiting)throw new Error('页面筛选或页码与任务不符，已暂停');
        let c=j.coverage[j.key];if(!c)c=j.coverage[j.key]={keyword:j.keywords[j.key],declared:list.total,initial:list.total,pages:0,found:0,failed:0,complete:false,error:''};
        j.seen=[...new Set([...j.seen,...list.rows.map(r=>r.summary[1])])];c.found=j.seen.length;c.declared=list.total;c.pages=list.page;
        j.pageCount=list.pages;j.listParams=list.params;j.queue=[];
        const done=new Set(await send({type:'keys'}));
        for(const row of list.rows){if(done.has(row.summary[1]))await send({type:'match',ctr:row.summary[1],keyword:c.keyword});else j.queue.push(row);}
      }else if(j.stage==='detail'){
        const ctr=j.current.summary[1];
        // A website rejection page must stop navigation, not be silently skipped.
        if(!document.body.innerText.includes(ctr))throw new Error('未加载预期详情，需检查官网访问状态');
        try{const detail=CDEParser.parseDetail(document,ctr);await send({type:'record',record:{ctr,summary:j.current.summary,detail,keywords:[j.keywords[j.key]]}});j.count++;}
        catch(e){j.coverage[j.key].failed++;await send({type:'failure',failure:{ctr,summary:j.current.summary,keyword:j.keywords[j.key],error:String(e.message),html:document.documentElement.outerHTML,time:new Date().toISOString()}});}
      }
      await advance(j);
    }catch(e){j.running=false;if(j.coverage[j.key])j.coverage[j.key].error=String(e.message);await save(j,`页面采集暂停：${e.message}`);}
  }
  chrome.runtime.onMessage.addListener((m,s,respond)=>{
    if(m.type!=='nav-begin')return;
    (async()=>{
      const list=CDEParser.parseList(document);
      const option=[...document.querySelectorAll('select option')].find(o=>o.textContent.trim()==='招募中');
      if(!option)throw new Error('官网缺少招募中筛选选项');
      const j={running:true,seed:list.params,recruiting:option.value,keywords:m.options.keywords,key:0,page:1,stage:'list',queue:[],seen:[],coverage:[],count:0,limit:m.options.limit};
      await navigate(j,'/clinicaltrials.searchlist.dhtml',params(j));
    })().catch(async e=>{await send({type:'nav-stop',reason:e.message});});respond({ok:true});
  });
  send({type:'nav-get'}).then(j=>{if(j?.running)step(j);}).catch(console.error);
})();
