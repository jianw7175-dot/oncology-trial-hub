const database = new Promise((resolve, reject) => {
  const req = indexedDB.open('cde-public-trials', 1);
  req.onupgradeneeded = () => req.result.createObjectStore('records', {keyPath: 'ctr'});
  req.onsuccess = () => resolve(req.result);
  req.onerror = () => reject(req.error);
});
async function records(action, value) {
  const db = await database;
  return new Promise((resolve, reject) => {
    const tx = db.transaction('records', action === 'put' ? 'readwrite' : 'readonly');
    const store = tx.objectStore('records');
    const req = action === 'put' ? store.put(value) : action === 'get' ? store.get(value) : action === 'keys' ? store.getAllKeys() : store.getAll();
    let result;
    req.onsuccess = () => { result = req.result; };
    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('本地保存中断'));
  });
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (sender.tab && !((sender.url || '').startsWith(chrome.runtime.getURL('')) || new URL(sender.url).hostname === 'www.chinadrugtrials.org.cn')) return false;
  (async () => {
    if(message.type==='nav-get'){const {navigationJob:j}=await chrome.storage.local.get('navigationJob');return j && (!sender.tab || j.tabId===sender.tab.id)?j:null;}
    if(message.type==='nav-save'){const j={...message.job,tabId:sender.tab.id};await chrome.storage.local.set({navigationJob:j,coverage:j.coverage,status:{running:j.running,count:j.count,tabId:j.tabId,message:message.message},updatedAt:new Date().toISOString()});return true;}
    if(message.type==='nav-stop'){const {navigationJob:j}=await chrome.storage.local.get('navigationJob');if(j)j.running=false;await chrome.storage.local.set({navigationJob:j||null,status:{running:false,message:message.reason||'已暂停，已保存的记录不会丢失'}});return true;}
    if (message.type === 'record') {
      const r = message.record;
      if (!/^CTR\d{8}$/.test(r?.ctr) || r.detail?.['登记号'] !== r.ctr) throw new Error('记录标识不匹配');
      await records('put', r);
      const saved=await chrome.storage.local.get('failures');const failures=saved.failures||{};delete failures[r.ctr];await chrome.storage.local.set({failures});
      return true;
    }
    if (message.type === 'failure') {const saved=await chrome.storage.local.get('failures');await chrome.storage.local.set({failures:{...(saved.failures||{}),[message.failure.ctr]:message.failure}});return true;}
    if (message.type === 'keys') return records('keys');
    if (message.type === 'match') {
      const r=await records('get',message.ctr);
      if(r){r.keywords=[...new Set([...r.keywords,message.keyword])];await records('put',r);}
      return true;
    }
    if (message.type === 'export') return {format:'cde-browser-v1', ...(await chrome.storage.local.get(['status','coverage','failures'])), records:await records('all')};
    if (message.type === 'status') {
      await chrome.storage.local.set({status:{...message.status,tabId:sender.tab?.id}, coverage:message.coverage || [], updatedAt:new Date().toISOString()});
      return true;
    }
    throw new Error('不支持的操作');
  })().then(data => respond({ok:true,data}), e => respond({ok:false,error:String(e.message || e)}));
  return true;
});

chrome.tabs.onUpdated.addListener(async(tabId,change)=>{
  if(change.status!=='complete')return;
  const {navigationJob:j}=await chrome.storage.local.get('navigationJob');
  if(!j?.running || j.tabId!==tabId)return;
  try{await chrome.scripting.executeScript({target:{tabId},files:['parser.js','navigation.js']});}
  catch(e){j.running=false;await chrome.storage.local.set({navigationJob:j,status:{running:false,message:'页面连接中断：'+e.message}});}
});
